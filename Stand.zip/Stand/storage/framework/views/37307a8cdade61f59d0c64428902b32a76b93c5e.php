<?php $__env->startSection('content'); ?>
<h1>
  Evento <?php echo e($estado->s_descripcion); ?>

</h1>
 
<p>Id estado; <?php echo e($estado->id_estado); ?></p>
<p>Descripcion: <?php echo e($estado->s_descripcion); ?></p>
<p>Fecha creación: <?php echo e($estado->created_at); ?></p>
<hr>
 
<a href="<?php echo e(route('estados.index')); ?>">Volver al índice</a>
<a href="<?php echo e(route('estados.show', $estado->id_estado)); ?>">Recargar</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>