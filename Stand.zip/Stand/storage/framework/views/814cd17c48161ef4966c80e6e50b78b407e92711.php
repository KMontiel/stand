<b>Cliente:</b> &nbsp;<?php echo e($demo->s_nombre); ?> <br/>

<h2>¡Aviso importante!</h2>

<p>
Hacemos de su conocimiento que <b>RESERVO UN STAND</b>, por lo que este correo es una confirmacion. si por 
alguna razon es un error lo invitamos a comunicarse a nuestros telefonos para su cancelación.
</p>

<b>Fecha Inicio:</b> &nbsp;<?php echo e($demo->d_inicio); ?> <br/>
<b>Fecha Fin:</b> &nbsp;<?php echo e($demo->d_fin); ?> <br/>
<b>Evento:</b> &nbsp;<?php echo e($demo->evento); ?> <br/>
<b>Lugar:</b> &nbsp;<?php echo e($demo->lugar); ?> <br/>
<b>Costo:</b> &nbsp;<?php echo e($demo->costo); ?> <br/>

<b>Registrado el :</b> &nbsp;<?php echo e($demo->created_at); ?> <br/>


<center><h4>Atentamente</h4> <h4>Promo Stand, S.C.</h4></center>