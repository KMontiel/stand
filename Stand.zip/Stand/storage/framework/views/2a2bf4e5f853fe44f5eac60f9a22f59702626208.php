<?php $__env->startSection('content'); ?>
<h1>
  Cliente <?php echo e($cliente->s_nombre); ?>

</h1>
 
<p>Id cliente; <?php echo e($cliente->id_cliente); ?></p>
<p>RFC: <?php echo e($cliente->s_rfc); ?></p>
<p>Nombre: <?php echo e($cliente->s_nombre); ?></p>
<p>Descripcion: <?php echo e($cliente->s_descripcion); ?></p>
<p>Telefono:<?php echo e($cliente->s_telefono); ?></p>
<p>Correo<?php echo e($cliente->s_correo); ?></p>
<p>Fecha creación: <?php echo e($cliente->created_at); ?></p>
<hr>
 
<a href="<?php echo e(route('clientes.index')); ?>">Volver al índice</a>
<a href="<?php echo e(route('clientes.show', $cliente->id_cliente)); ?>">Recargar</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>