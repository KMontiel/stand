<?php $__env->startSection('content'); ?>
<h1 class="text-primary">Lista de Estados</h1>
 
<table class="table table-bordered" id="tableEstados">
  <thead>
    <tr>
        <th class="text-center">Id estado</th>
        <th class="text-center">Descripcion</th>
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($estado->id_estado); ?></td>
            <td class="text-center"><?php echo e($estado->s_descripcion); ?></td>
            <td>
                <a href="<?php echo e(route('estados.show', $estado->id_estado)); ?>" class="btn btn-info">Ver</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>