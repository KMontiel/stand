<?php $__env->startSection('content'); ?>
<h1 class="text-primary">Lista de Lugares</h1>
 
<table class="table table-bordered" id="tableLugares">
  <thead>
    <tr>
        <th class="text-center">Id Lugar</th>
        <th class="text-center">Descripcion</th>
        <th class="text-center">Costo</th>
        <th class="text-center">Habilitado</th>
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $lugares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($lugar->id_lugar); ?></td>
            <td class="text-center"><?php echo e($lugar->s_descripcion); ?></td>
            <td class="text-center"><?php echo e($lugar->n_costo); ?></td>
            <td class="text-center"><?php echo e($lugar->b_habilitado); ?></td>  
            <td>
                <a href="<?php echo e(route('lugares.show', $lugar->id_lugar)); ?>" class="btn btn-info">Ver</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>