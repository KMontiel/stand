<?php $__env->startSection('content'); ?>
<h1 class="text-primary">Lista de Clientes</h1>
 
<table class="table table-bordered" id="tableClientes">
  <thead>
    <tr>
        <th class="text-center">Id cliente</th>
        <th class="text-center">RFC</th>
        <th class="text-center">Nombre</th>
        <th class="text-center">Descripcion</th>
        <th class="text-center">Telefono</th>
        <th class="text-center">Correo</th>
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($cliente->id_cliente); ?></td>
            <td class="text-center"><?php echo e($cliente->s_rfc); ?></td>
            <td class="text-center"><?php echo e($cliente->s_nombre); ?></td>
            <td class="text-center"><?php echo e($cliente->s_descripcion); ?></td>
            <td class="text-center"><?php echo e($cliente->s_telefono); ?></td>
            <td class="text-center"><?php echo e($cliente->s_correo); ?></td>  
            <td>
                <a href="<?php echo e(route('clientes.show', $cliente->id_cliente)); ?>" class="btn btn-info">Ver</a>
                <a href="<?php echo e(route('clientes.edit', $cliente->id_cliente)); ?>" class="btn btn-info">Editar</a>
                <td>
                <form action="<?php echo e(route('clientes.destroy', $cliente->id_cliente)); ?>" method="POST"  role="form">
                   <?php echo e(csrf_field()); ?>

                   <input name="_method" type="hidden" value="DELETE"> 
                   <button class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span></button>
                 </td>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>