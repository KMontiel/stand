<?php $__env->startSection('content'); ?>
<h1>
  Evento <?php echo e($lugar->s_descripcion); ?>

</h1>
 
<p>Id lugar; <?php echo e($lugar->id_cliente); ?></p>
<p>Descripcion: <?php echo e($lugar->s_descripcion); ?></p>
<p>Costo: <?php echo e($lugar->n_costo); ?></p>
<p>Habilitado<?php echo e($lugar->b_habilitado); ?></p>
<p>Fecha creación: <?php echo e($lugar->created_at); ?></p>
<hr>
 
<a href="<?php echo e(route('lugares.index')); ?>">Volver al índice</a>
<a href="<?php echo e(route('lugares.show', $lugar->id_lugar)); ?>">Recargar</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>