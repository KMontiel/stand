<?php $__env->startSection('content'); ?>
<h1>
  Ocupacion <?php echo e($ocupacion->id_ocupacion); ?>

</h1>
 
<p>Id ocupacion; <?php echo e($ocupacion->id_estado); ?></p>
<p>Fecha Inicio: <?php echo e($ocupacion->d_inicio); ?></p>
<p>Hora Inicio: <?php echo e($ocupacion->d_hora_inicio); ?></p>
<p>Fecha Fin: <?php echo e($ocupacion->d_fin); ?></p>
<p>Hora Fin: <?php echo e($ocupacion->d_hora_fin); ?></p>
<p>Fecha Registro: <?php echo e($ocupacion->d_registro); ?></p>
<p>Hora Registro: <?php echo e($ocupacion->d_hora_registro); ?></p>
<p>Evento: <?php echo e($ocupacion->id_evento); ?></p>
<p>Lugar: <?php echo e($ocupacion->id_lugar); ?></p>
<p>Cliente: <?php echo e($ocupacion->id_cliente); ?></p>
<p>Estado: <?php echo e($ocupacion->id_estado); ?></p>
<p>Fecha creación: <?php echo e($ocupacion->created_at); ?></p>
<hr>
 
<a href="<?php echo e(route('ocupaciones.index')); ?>">Volver al índice</a>
<a href="<?php echo e(route('ocupaciones.show', $ocupacion->id_ocupacion)); ?>">Recargar</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>