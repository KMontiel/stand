<?php $__env->startSection('content'); ?>
<h1 class="text-primary">Lista de Ocupaciones</h1>
 
<table class="table table-bordered" id="tableOcupacion">
  <thead>
    <tr>
        <th class="text-center">Id ocupacion</th>
        <th class="text-center">Fecha Inicio</th>
        <th class="text-center">Hora Inicio</th>
        <th class="text-center">Fecha Fin</th>
        <th class="text-center">Hora Fin</th>
        <th class="text-center">Fecha Registro</th>
        <th class="text-center">Hora Registro</th>
        <th class="text-center">Evento</th>
        <th class="text-center">Lugar</th> 
        <th class="text-center">Cliente</th>
        <th class="text-center">Estado</th>                                
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $ocupaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ocupacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($ocupacion->id_ocupacion); ?></td>
            <td class="text-center"><?php echo e($ocupacion->d_inicio); ?></td>
            <td class="text-center"><?php echo e($ocupacion->d_hora_inicio); ?></td>
            <td class="text-center"><?php echo e($ocupacion->d_fin); ?></td>
            <td class="text-center"><?php echo e($ocupacion->d_hora_inicio); ?></td> 
            <td class="text-center"><?php echo e($ocupacion->d_registro); ?></td>
            <td class="text-center"><?php echo e($ocupacion->d_hora_registro); ?></td>
            <td class="text-center"><?php echo e($ocupacion->evento); ?></td>
            <td class="text-center"><?php echo e($ocupacion->lugar); ?></td>   
            <td class="text-center"><?php echo e($ocupacion->cliente); ?></td>
            <td class="text-center"><?php echo e($ocupacion->estado); ?></td>                                                
            <td>
                <a href="<?php echo e(route('ocupaciones.show', $ocupacion->id_ocupacion)); ?>" class="btn btn-info">Ver</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>