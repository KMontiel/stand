<?php $__env->startSection('content'); ?>
<h1 class="text-primary">Lista de Eventos</h1>
 
<table class="table table-bordered" id="tableEventos">
  <thead>
    <tr>
        <th class="text-center">Id Evento</th>
        <th class="text-center">Descripcion</th>
        <th class="text-center">Fecha inicio</th>
        <th class="text-center">Fecha fin</th>
        <th class="text-center">Reservado</th>
        <th class="text-center">Habilitado</th>
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($evento->id_evento); ?></td>
            <td class="text-center"><?php echo e($evento->s_descripcion); ?></td>
            <td class="text-center"><?php echo e($evento->d_inicio); ?></td>
            <td class="text-center"><?php echo e($evento->d_fin); ?></td>
            <td class="text-center"><?php echo e($evento->b_reserva_parcial); ?></td>
            <td class="text-center"><?php echo e($evento->b_habilitado); ?></td>  
            <td>
                <a href="<?php echo e(route('eventos.show', $evento->id_evento)); ?>" class="btn btn-info">Ver</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>