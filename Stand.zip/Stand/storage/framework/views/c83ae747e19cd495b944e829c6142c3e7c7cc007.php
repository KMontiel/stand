<?php $__env->startSection('content'); ?>


<h1>Editar Cliente</h1>

<div class="row">
    <section class="content">
        <div class="col-md-8 col-md-offset-2">
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>
 
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Nuevo Cliente</h3>
                </div>
                <div class="panel-body">                    
                    <div class="table-container">
                        <form method="POST" action="<?php echo e(route('clientes.update',$cliente->id_cliente)); ?>"  role="form">
                            <?php echo e(csrf_field()); ?>

                            <input name="_method" type="hidden" value="PATCH">
                            <div class="row">
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="s_rfc" id="s_rfc" class="form-control input-sm" value="<?php echo e($cliente->s_rfc); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="s_nombre" id="s_nombre" class="form-control input-sm" value="<?php echo e($cliente->s_nombre); ?>" placeholder="RFC">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="s_descripcion" id="s_descripcion" class="form-control input-sm" value="<?php echo e($cliente->s_descripcion); ?>" placeholder="Descripcion">
                                    </div>
                                </div>                                
                            </div>
                            <div class="row"> 
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="s_telefono" id="s_telefono" class="form-control input-sm" value="<?php echo e($cliente->s_telefono); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="s_correo" id="s_correo" class="form-control input-sm" value="<?php echo e($cliente->s_correo); ?>">
                                    </div>
                                </div>                                
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <input type="submit"  value="Actualizar" class="btn btn-success btn-block">
                                    <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-info btn-block" >Atrás</a>
                                </div>  
                            </div>
                            </div>
                        </form>
                    </div>
                </div>
 
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>