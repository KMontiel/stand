<?php $__env->startSection('content'); ?>
<h1>
  Evento <?php echo e($evento->s_descripcion); ?>

</h1>
 
<p>Id evento; <?php echo e($evento->id_cliente); ?></p>
<p>Descripcion: <?php echo e($evento->s_descripcion); ?></p>
<p>Fecha Inicio: <?php echo e($evento->d_inicio); ?></p>
<p>Fecha Fin: <?php echo e($evento->d_fin); ?></p>
<p>Reservado:<?php echo e($evento->b_reserva_parcial); ?></p>
<p>Habilitado<?php echo e($evento->b_habilitado); ?></p>
<p>Fecha creación: <?php echo e($evento->created_at); ?></p>
<hr>
 
<a href="<?php echo e(route('eventos.index')); ?>">Volver al índice</a>
<a href="<?php echo e(route('eventos.show', $evento->id_evento)); ?>">Recargar</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>