<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class eventos extends Model
{
    protected $table='c_eventos';
    protected $primaryKey= 'id_evento';
    protected $fillable = ['id_evento',
				           's_descripcion',
				           'd_inicio',
				           'd_fin',
				           'b_reserva_parcial',
				           'b_habilitado'];
	protected $hidden = ['created_at','updated_at'];	
}
