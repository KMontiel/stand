<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\Reservado as EnviaCorreo;
use Illuminate\Support\Facades\Mail;


class MailController extends Controller
{
    public function send($s_nombre, $s_mail)
    {
  
      $objDemo = new \stdClass();
      $objDemo->s_nombre = $s_nombre;
      $objDemo->s_mail = $s_mail;

      try {
        Mail::to($objDemo->s_mail,$objDemo->s_nombre)
            ->send(new EnviaCorreo($objDemo));

            if( count(Mail::failures()) > 0 ) {
              return "fail";
            } else {
              return "send";
            }

      } catch (\Exception $e) {
        return "fail";
      }
    }
}
