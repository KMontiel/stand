<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\Reservado as EnviaCorreo;
use Illuminate\Support\Facades\Mail;
use App\Ocupacion;
use Illuminate\Support\Facades\DB;


class MailController extends Controller
{
    public function send($id_ocupacion)
    {
  
      $objDemo = new \stdClass();
      $objDemo = DB::table('t_ocupaciones')
               ->select('t_ocupaciones.*',
                'c_clientes.s_nombre as s_nombre',
                'c_estados.s_descripcion as estado',
                'c_eventos.s_descripcion as evento',
                'c_lugares.s_descripcion as lugar',
                'c_lugares.n_costo as costo',
                'c_clientes.s_correo as s_correo')
               ->join('c_clientes', 't_ocupaciones.id_cliente', '=', 'c_clientes.id_cliente')
               ->join('c_estados', 't_ocupaciones.id_estado', '=', 'c_estados.id_estado')
               ->join('c_eventos', 't_ocupaciones.id_evento', '=', 'c_eventos.id_evento')
               ->join('c_lugares', 't_ocupaciones.id_lugar', '=', 'c_lugares.id_lugar')
               ->where('t_ocupaciones.id_ocupacion','=', $id_ocupacion)
               ->first(); 

      try {
        Mail::to($objDemo->s_correo,$objDemo->s_nombre)
            ->send(new EnviaCorreo($objDemo));

     if( count(Mail::failures()) > 0 ) {
              return "fail";
            } else {
              return "send";
            }

      } 
         catch (\Exception $e) {
        //return "fail";   
        return $e;   
      }
    }
}
