<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Clientes;

class ClientesController extends Controller
{
    public function index()
	  {
        $clientes=Clientes::all();
        return response()->json($clientes);
	  }

	public function show($id_cliente)
	{
	  $cliente = Clientes::find($id_cliente);
	  return response()->json($cliente);
	}

    public function create()
    {
        //
    }
    
    public function store(Request $request)
    {
        $cliente = Clientes::create($request->all());
        return response()->json($cliente, 201);
    }

    public function edit($id_cliente) 
    {
        return Clientes::findOrFail($id_cliente);
    }

    public function update(Request $request, $id_cliente)
    {
        $cliente= Clientes::find($id_cliente);
        $cliente->update(['s_rfc'        => $request->$rfc,
                          's_nombre'     => $request->$nombre,
                          's_descripcion'=> $request->$descripcion,
                          's_telefono'   => $request->$telefono,
                          's_correo'     => $request->$correo,
                          ]);
        
        return response()->json($cliente, 200);
    }


    public function destroy($id_cliente) 
    {
        $cliente= Clientes::find($id_cliente)->delete();
        return response()->json(null, 204);
    }

    public function getClienteRFC($rfc)
    {
      return Clientes::where('s_rfc',$rfc)->first();      
    }

}
