<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Clientes;

class ClientesController extends Controller
{
    public function index()
	  {
	    $clientes = Clientes::get();
	    return view('clientes.index')->with('clientes', $clientes);
	  }

	public function show($id_cliente)
	{
	  $cliente = Clientes::find($id_cliente);
	  return view('clientes.show')->with('cliente', $cliente);
	}

	public function create()
    {    	
    	return View('clientes.create');        
    }

    public function store(Request $request)
    {
        $this->validate($request,[ 's_rfc'=>'required', 's_nombre'=>'required', 's_descripcion'=>'required', 's_telefono'=>'required', 's_correo'=>'required']);
        Clientes::create($request->all());
        return redirect()->route('clientes.index')->with('success','Registro creado satisfactoriamente');
    }

    public function edit($id_cliente)
    {
        $cliente=Clientes::find($id_cliente);
        return view('clientes.edit',compact('cliente'));
    }
 
    public function update(Request $request, $id_cliente)    {
        
        $this->validate($request,[ 's_rfc'=>'required', 's_nombre'=>'required', 's_descripcion'=>'required', 's_telefono'=>'required', 's_correo'=>'required']);
 
        Clientes::find($id_cliente)->update($request->all());
        return redirect()->route('clientes.index')->with('success','Registro actualizado satisfactoriamente');
 
    }

    public function destroy($id_cliente) 
    {
        Clientes::find($id_cliente)->delete();
        return redirect()->route('clientes.index')->with('success','Registro eliminado satisfactoriamente');
    }

    public function getClientes(){
        $clientes=Clientes::all();
        return response()->json($clientes);
    }
}
