<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ocupacion;
use Illuminate\Support\Facades\DB;

class OcupacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $ocupaciones = DB::table('t_ocupaciones')
                       ->join('c_clientes', 't_ocupaciones.id_cliente', '=', 'c_clientes.id_cliente')
                       ->join('c_estados', 't_ocupaciones.id_estado', '=', 'c_estados.id_estado')
                       ->join('c_eventos', 't_ocupaciones.id_evento', '=', 'c_eventos.id_evento')
                       ->join('c_lugares', 't_ocupaciones.id_lugar', '=', 'c_lugares.id_lugar')
                       ->select('t_ocupaciones.*','c_clientes.s_nombre as cliente', 'c_estados.s_descripcion as estado','c_eventos.s_descripcion as evento', 'c_lugares.s_descripcion as lugar')
                       ->get(); 

        return view('ocupaciones.index')->with('ocupaciones', $ocupaciones);        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id_ocupacion)
    {
      $ocupacion = Ocupacion::find($id_ocupacion);

      return view('ocupaciones.show')->with('ocupacion', $ocupacion);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function getOcupaciones(){

        $ocupaciones = DB::table('t_ocupaciones')
                       ->join('c_clientes', 't_ocupaciones.id_cliente', '=', 'c_clientes.id_cliente')
                       ->join('c_estados', 't_ocupaciones.id_estado', '=', 'c_estados.id_estado')
                       ->join('c_eventos', 't_ocupaciones.id_evento', '=', 'c_eventos.id_evento')
                       ->join('c_lugares', 't_ocupaciones.id_lugar', '=', 'c_lugares.id_lugar')
                       ->select('t_ocupaciones.*','c_clientes.s_nombre as cliente', 'c_estados.s_descripcion as estado','c_eventos.s_descripcion as evento', 'c_lugares.s_descripcion as lugar')
                       ->get(); 
        return response()->json($ocupaciones);
    } 

    public function getEstadoOcupaciones($id_evento){

        $ocupacion = DB::table('c_lugares')
                       ->leftJoin('t_ocupaciones',function($join) use ($id_evento){
                                         $join->on('c_lugares.id_lugar', '=', 't_ocupaciones.id_lugar');
                                         $join->on('t_ocupaciones.id_evento', DB::raw($id_evento));
                                         })
                       ->select('c_lugares.s_descripcion as s_descripcion', DB::raw('if(ifnull(t_ocupaciones.id_cliente,0)=0,"disponible","ocupado") AS estado'))                      
                       ->get(); 

        return response()->json($ocupacion);
    } 

    public function getOcupacion($id_evento){

        $ocupacion = DB::table('t_ocupaciones')
                       ->where('t_ocupaciones.id_evento','=',$id_evento)                     
                       ->select('t_ocupaciones.*')
                       ->first(); 

        return response()->json($ocupacion);
    } 

    public function getOcupacionDetalleCliente($id_evento, $id_lugar){

        $ocupacion = DB::table('t_ocupaciones')
                       ->select('t_ocupaciones.*',
                        'c_clientes.s_nombre as cliente',
                        'c_estados.s_descripcion as estado',
                        'c_eventos.s_descripcion as evento',
                        'c_lugares.s_descripcion as lugar',
                        'c_lugares.n_costo as costo')
                       ->join('c_clientes', 't_ocupaciones.id_cliente', '=', 'c_clientes.id_cliente')
                       ->join('c_estados', 't_ocupaciones.id_estado', '=', 'c_estados.id_estado')
                       ->join('c_eventos', 't_ocupaciones.id_evento', '=', 'c_eventos.id_evento')
                       ->join('c_lugares', 't_ocupaciones.id_lugar', '=', 'c_lugares.id_lugar')
                       ->where('t_ocupaciones.id_evento','=', $id_evento)
                       ->where('t_ocupaciones.id_lugar', '=', $id_lugar)
                       ->first(); 

        return response()->json($ocupacion);
    } 

}
