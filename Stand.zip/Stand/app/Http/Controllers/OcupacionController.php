<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ocupacion;
use Illuminate\Support\Facades\DB;

class OcupacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $ocupaciones = DB::table('t_ocupaciones')
                       ->join('c_clientes', 't_ocupaciones.id_cliente', '=', 'c_clientes.id_cliente')
                       ->join('c_estados', 't_ocupaciones.id_estado', '=', 'c_estados.id_estado')
                       ->join('c_eventos', 't_ocupaciones.id_evento', '=', 'c_eventos.id_evento')
                       ->join('c_lugares', 't_ocupaciones.id_lugar', '=', 'c_lugares.id_lugar')
                       ->select('t_ocupaciones.*','c_clientes.s_nombre as cliente', 'c_estados.s_descripcion as estado','c_eventos.s_descripcion as evento', 'c_lugares.s_descripcion as lugar')
                       ->get(); 

        return response()->json($ocupaciones);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $ocupacion = Ocupacion::create($request->all());
        return response()->json($ocupacion, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id_ocupacion)
    {
        $ocupacion = DB::table('t_ocupaciones')
                       ->select('t_ocupaciones.*',
                        'c_clientes.s_nombre as cliente',
                        'c_estados.s_descripcion as estado',
                        'c_eventos.s_descripcion as evento',
                        'c_lugares.s_descripcion as lugar',
                        'c_lugares.n_costo as costo')
                       ->join('c_clientes', 't_ocupaciones.id_cliente', '=', 'c_clientes.id_cliente')
                       ->join('c_estados', 't_ocupaciones.id_estado', '=', 'c_estados.id_estado')
                       ->join('c_eventos', 't_ocupaciones.id_evento', '=', 'c_eventos.id_evento')
                       ->join('c_lugares', 't_ocupaciones.id_lugar', '=', 'c_lugares.id_lugar')
                       ->where('t_ocupaciones.id_ocupacion','=', $id_ocupacion)
                       ->first(); 

        return response()->json($ocupacion);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id_ocupacion)
    {
       return Ocupacion::findOrFail($id_ocupacion);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id_ocupacion)
    {
        $ocupacion= Ocupacion::find($id_ocupacion);
        $ocupacion->update(['d_inicio'        => $request->$d_inicio,
                          'd_hora_inicio'     => $request->$d_hora_fin,
                          'd_fin'             => $request->$d_fin,
                          'd_hora_fin'        => $request->$d_hora_fin,
                          'd_registro'        => $request->$d_registro,
                          'd_hora_registro'   => $request->$d_hora_registro,
                          'id_evento'         => $request->$id_evento,
                          'id_lugar'          => $request->$id_lugar,
                          'id_cliente'        => $request->$id_cliente,
                          'id_estado'         => $request->$id_estado
                          ]);
        
        return response()->json($ocupacion, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_ocupacion)
    {
        $ocupacion= Ocupacion::find($id_ocupacion)->delete();
        return response()->json(null, 204);
    }

    public function getEstadoOcupaciones($id_evento){

    $ocupaciones = DB::table('t_ocupaciones AS t')    
                       ->select('l.id_lugar','l.s_descripcion as lugar','t.id_ocupacion','t.d_inicio', 't.d_hora_inicio','t.d_fin', 't.d_hora_fin', 't.d_registro', 't.d_hora_registro', 't.id_evento', 't.id_cliente', 't.id_estado', DB::raw('IFNULL((SELECT c_estados.s_descripcion FROM c_estados WHERE c_estados.id_estado = t.id_estado),"Disponible") AS estado'))
                       ->rightJoin('c_lugares as l',function($join) use ($id_evento){
                                 $join->on('t.id_lugar', '=', 'l.id_lugar');
                                 $join->on('t.id_evento','=',  DB::raw($id_evento));
                                 })
                       ->orderBy('l.id_lugar')
                       ->get();

           return response()->json($ocupaciones);
    } 

}
