<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\eventos;
use Illuminate\Support\Facades\DB;

class EventosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $eventos = eventos::where('b_habilitado',1)
                ->where(function ($query) {
                  $query->where('d_inicio', '>=', now()->format('Y-m-d'))
                        ->orWhere('d_fin', '>=',now()->format('Y-m-d'));
                 })
                ->orderBy('s_descripcion', 'desc')
                ->get();

        return view('eventos.index')->with('eventos', $eventos);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id_evento)
    {
      $evento = eventos::find($id_evento);
      return view('eventos.show')->with('evento', $evento);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function getEventos(){
        $eventos = eventos::where('b_habilitado',1)
                ->where(function ($query) {
                  $query->where('d_inicio', '>=', now()->format('Y-m-d'))
                        ->orWhere('d_fin', '>=',now()->format('Y-m-d'));
                 })
                ->orderBy('s_descripcion', 'desc')
                ->get();
                
        return response()->json($eventos);
    }

    public function getEvento($id_evento){

        $ocupacion = DB::table('c_eventos')
                       ->where('c_eventos.id_evento','=',$id_evento)                     
                       ->select('c_eventos.*')
                       ->first(); 

        return response()->json($ocupacion);
    } 
}
