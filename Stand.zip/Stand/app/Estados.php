<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Estados extends Model
{
    protected $table='c_estados';
    protected $primaryKey= 'id_estado';
    protected $fillable = ['id_estado',
				           's_descripcion'];
	protected $hidden = ['created_at','updated_at'];
}
