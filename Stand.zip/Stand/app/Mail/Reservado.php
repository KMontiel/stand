<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class Reservado extends Mailable
{
    use Queueable, SerializesModels;

    public $demo;

    public function __construct($demo)
    {
       $this->demo=$demo;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

    $data = array(
    'demo' =>$this->demo
    );
  
    $this->view('emails.mailreserva')
    ->with([
                  'testVarOne' => '1',
                  'testVarTwo' => '2',
            ])
    ->from('vberisowrk@gmail.com',"Reservaciones")
    ->subject('Reservaciones de Stand')  
    }
}
