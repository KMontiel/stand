<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clientes extends Model 
{
	
    protected $table='c_clientes';
    protected $primaryKey= 'id_cliente';
    protected $fillable = ['id_cliente',
				           's_rfc',
				           's_nombre',
				           's_descripcion',
				           's_telefono',
				           's_correo'];
	protected $hidden = ['created_at','updated_at'];			           
}
