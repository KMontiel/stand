<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ocupacion extends Model
{
    protected $table='t_ocupaciones';
    protected $primaryKey= 'id_ocupacion';
    protected $fillable = ['id_ocupacion',
				           'd_inicio',
				           'd_hora_inicio',
				           'd_fin',
				           'd_hora_fin',
				           'd_registro',
				           'd_hora_registro',
				           'id_evento',
				           'id_lugar',
				           'id_cliente',
				           'id_estado'];
	protected $hidden = ['created_at','updated_at'];
}
