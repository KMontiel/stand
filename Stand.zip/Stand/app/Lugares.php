<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lugares extends Model
{
    protected $table='c_lugares';
    protected $primaryKey= 'id_lugar';
    protected $fillable = ['id_lugar',
				           's_descripcion',
				           'n_costo',
				           'b_habilitado'];
	protected $hidden = ['created_at','updated_at'];	
}
