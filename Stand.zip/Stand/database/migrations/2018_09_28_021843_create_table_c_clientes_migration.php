<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableCClientesMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() 
    {
        Schema::create('c_clientes', function (Blueprint $table) {
            $table->increments('id_cliente');
            $table->string('s_rfc',13);
            $table->string('s_nombre',200);
            $table->string('s_descripcion',250);
            $table->string('s_telefono',15);
            $table->string('s_correo',45);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('c_clientes');
    }
}
