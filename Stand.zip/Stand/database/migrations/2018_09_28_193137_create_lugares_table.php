<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLugaresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('c_lugares', function (Blueprint $table) {
            $table->increments('id_lugar');
            $table->string('s_descripcion',45);
            $table->decimal('n_costo',10,2);
            $table->boolean('b_habilitado')->default(false); 
            $table->timestamps();
        }); 
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('c_lugares');
    }
}
