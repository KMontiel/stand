<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEventosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('c_eventos', function (Blueprint $table) {
            $table->increments('id_evento');
            $table->string('s_descripcion',45);
            $table->date('d_inicio');
            $table->date('d_fin');
            $table->boolean('b_reserva_parcial')->default(false);
            $table->boolean('b_habilitado')->default(false); 
            $table->timestamps();
        });      
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('c_eventos');
    }
}
