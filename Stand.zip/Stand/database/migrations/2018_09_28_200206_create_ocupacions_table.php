<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOcupacionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_ocupaciones', function (Blueprint $table) {
            $table->increments('id_ocupacion');
            $table->date('d_inicio')->nullable();
            $table->time('d_hora_inicio')->nullable();
            $table->date('d_fin')->nullable();
            $table->time('d_hora_fin')->nullable();
            $table->date('d_registro')->nullable();
            $table->time('d_hora_registro')->nullable();
            $table->integer('id_evento')->nullable();
            $table->integer('id_lugar')->nullable();
            $table->integer('id_cliente')->nullable();
            $table->integer('id_estado')->nullable();                        
            $table->timestamps();
        });  
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_ocupaciones');
    }
}
