@extends('app')
@section('content')
<h1>
  Estado {{ $estado->s_descripcion}}
</h1>
 
<p>Id estado; {{ $estado->id_estado}}</p>
<p>Descripcion: {{ $estado->s_descripcion}}</p>
<p>Fecha creación: {{ $estado->created_at }}</p>
<hr>
 
<a href="{{ route('estados.index') }}">Volver al índice</a>
<a href="{{ route('estados.show', $estado->id_estado) }}">Recargar</a>
@stop