@extends('app')
@section('content')
<h1 class="text-primary">Lista de Estados</h1>
 
<table class="table table-bordered" id="tableEstados">
  <thead>
    <tr>
        <th class="text-center">Id estado</th>
        <th class="text-center">Descripcion</th>
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    @foreach($estados as $estado)
        <tr>
            <td class="text-center">{{ $estado->id_estado}}</td>
            <td class="text-center">{{ $estado->s_descripcion}}</td>
            <td>
                <a href="{{ route('estados.show', $estado->id_estado) }}" class="btn btn-info">Ver</a>
            </td>
        </tr>
    @endforeach
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
@stop