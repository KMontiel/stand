<b>Cliente:</b> &nbsp;{{ $demo->s_nombre }} <br/>

<h2>¡Aviso importante!</h2>

<p>
Hacemos de su conocimiento que <b>RESERVO UN STAND</b>, por lo que este correo es una confirmacion. si por 
alguna razon es un error lo invitamos a comunicarse a nuestros telefonos para su cancelación.
</p>

<b>Fecha Inicio:</b> &nbsp;{{ $demo->d_inicio }} <br/>
<b>Fecha Fin:</b> &nbsp;{{ $demo->d_fin }} <br/>
<b>Evento:</b> &nbsp;{{ $demo->evento }} <br/>
<b>Lugar:</b> &nbsp;{{ $demo->lugar }} <br/>
<b>Costo:</b> &nbsp;{{ $demo->costo }} <br/>

<b>Registrado el :</b> &nbsp;{{ $demo->created_at }} <br/>


<center><h4>Atentamente</h4> <h4>Promo Stand, S.C.</h4></center>