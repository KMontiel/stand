<b>Cliente:</b> &nbsp;{{ $demo->s_nombre }} <br/>

<h2>¡Aviso importante!</h2>

<p>
Hacemos de su conocimiento que <b>RESERVO UN STAND</b>, por lo que este correo es una confirmacion. si por 
alguna razon es un error lo invitamos a comunicarse a nuestros telefonos para su cancelación.
</p>


<center><h4>Atentamente</h4> <h4>Promo Stand, S.C.</h4></center>