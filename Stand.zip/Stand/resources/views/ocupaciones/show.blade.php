@extends('app')
@section('content')
<h1>
  Ocupacion {{ $ocupacion->id_ocupacion}}
</h1>
 
<p>Id ocupacion; {{ $ocupacion->id_estado}}</p>
<p>Fecha Inicio: {{ $ocupacion->d_inicio}}</p>
<p>Hora Inicio: {{ $ocupacion->d_hora_inicio}}</p>
<p>Fecha Fin: {{ $ocupacion->d_fin}}</p>
<p>Hora Fin: {{ $ocupacion->d_hora_fin}}</p>
<p>Fecha Registro: {{ $ocupacion->d_registro}}</p>
<p>Hora Registro: {{ $ocupacion->d_hora_registro}}</p>
<p>Evento: {{ $ocupacion->id_evento}}</p>
<p>Lugar: {{ $ocupacion->id_lugar}}</p>
<p>Cliente: {{ $ocupacion->id_cliente}}</p>
<p>Estado: {{ $ocupacion->id_estado}}</p>
<p>Fecha creación: {{ $ocupacion->created_at }}</p>
<hr>
 
<a href="{{ route('ocupaciones.index') }}">Volver al índice</a>
<a href="{{ route('ocupaciones.show', $ocupacion->id_ocupacion) }}">Recargar</a>
@stop