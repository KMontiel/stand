@extends('app')
@section('content')
<h1 class="text-primary">Lista de Ocupaciones</h1>
 
<table class="table table-bordered" id="tableOcupacion">
  <thead>
    <tr>
        <th class="text-center">Id ocupacion</th>
        <th class="text-center">Fecha Inicio</th>
        <th class="text-center">Hora Inicio</th>
        <th class="text-center">Fecha Fin</th>
        <th class="text-center">Hora Fin</th>
        <th class="text-center">Fecha Registro</th>
        <th class="text-center">Hora Registro</th>
        <th class="text-center">Evento</th>
        <th class="text-center">Lugar</th> 
        <th class="text-center">Cliente</th>
        <th class="text-center">Estado</th>                                
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    @foreach($ocupaciones as $ocupacion)
        <tr>
            <td class="text-center">{{ $ocupacion->id_ocupacion}}</td>
            <td class="text-center">{{ $ocupacion->d_inicio}}</td>
            <td class="text-center">{{ $ocupacion->d_hora_inicio}}</td>
            <td class="text-center">{{ $ocupacion->d_fin}}</td>
            <td class="text-center">{{ $ocupacion->d_hora_inicio}}</td> 
            <td class="text-center">{{ $ocupacion->d_registro}}</td>
            <td class="text-center">{{ $ocupacion->d_hora_registro}}</td>
            <td class="text-center">{{ $ocupacion->evento}}</td>
            <td class="text-center">{{ $ocupacion->lugar}}</td>   
            <td class="text-center">{{ $ocupacion->cliente}}</td>
            <td class="text-center">{{ $ocupacion->estado}}</td>                                                
            <td>
                <a href="{{ route('ocupaciones.show', $ocupacion->id_ocupacion) }}" class="btn btn-info">Ver</a>
            </td>
        </tr>
    @endforeach
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
@stop