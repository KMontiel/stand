@extends('app')
@section('content')
<h1>
  Cliente {{ $cliente->s_nombre}}
</h1>
 
<p>Id cliente; {{ $cliente->id_cliente}}</p>
<p>RFC: {{ $cliente->s_rfc}}</p>
<p>Nombre: {{ $cliente->s_nombre }}</p>
<p>Descripcion: {{ $cliente->s_descripcion}}</p>
<p>Telefono:{{ $cliente->s_telefono}}</p>
<p>Correo{{ $cliente->s_correo}}</p>
<p>Fecha creación: {{ $cliente->created_at }}</p>
<hr>
 
<a href="{{ route('clientes.index') }}">Volver al índice</a>
<a href="{{ route('clientes.show', $cliente->id_cliente) }}">Recargar</a>
@stop