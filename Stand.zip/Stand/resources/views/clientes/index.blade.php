@extends('app')
@section('content')
<h1 class="text-primary">Lista de Clientes</h1>
 
<table class="table table-bordered" id="tableClientes">
  <thead>
    <tr>
        <th class="text-center">Id cliente</th>
        <th class="text-center">RFC</th>
        <th class="text-center">Nombre</th>
        <th class="text-center">Descripcion</th>
        <th class="text-center">Telefono</th>
        <th class="text-center">Correo</th>
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    @foreach($clientes as $cliente)
        <tr>
            <td class="text-center">{{ $cliente->id_cliente}}</td>
            <td class="text-center">{{ $cliente->s_rfc}}</td>
            <td class="text-center">{{ $cliente->s_nombre }}</td>
            <td class="text-center">{{ $cliente->s_descripcion}}</td>
            <td class="text-center">{{ $cliente->s_telefono}}</td>
            <td class="text-center">{{ $cliente->s_correo}}</td>  
            <td>
                <a href="{{ route('clientes.show', $cliente->id_cliente) }}" class="btn btn-info">Ver</a>
                <a href="{{ route('clientes.edit', $cliente->id_cliente) }}" class="btn btn-info">Editar</a>
                <td>
                <form action="{{ route('clientes.destroy', $cliente->id_cliente) }}" method="POST"  role="form">
                   {{csrf_field()}}
                   <input name="_method" type="hidden" value="DELETE"> 
                   <button class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span></button>
                 </td>
            </td>
        </tr>
    @endforeach
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
@stop