@extends('app')
@section('content')
<h1 class="text-primary">Lista de Eventos</h1>
 
<table class="table table-bordered" id="tableEventos">
  <thead>
    <tr>
        <th class="text-center">Id Evento</th>
        <th class="text-center">Descripcion</th>
        <th class="text-center">Fecha inicio</th>
        <th class="text-center">Fecha fin</th>
        <th class="text-center">Reservado</th>
        <th class="text-center">Habilitado</th>
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    @foreach($eventos as $evento)
        <tr>
            <td class="text-center">{{ $evento->id_evento}}</td>
            <td class="text-center">{{ $evento->s_descripcion}}</td>
            <td class="text-center">{{ $evento->d_inicio }}</td>
            <td class="text-center">{{ $evento->d_fin}}</td>
            <td class="text-center">{{ $evento->b_reserva_parcial}}</td>
            <td class="text-center">{{ $evento->b_habilitado}}</td>  
            <td>
                <a href="{{ route('eventos.show', $evento->id_evento) }}" class="btn btn-info">Ver</a>
            </td>
        </tr>
    @endforeach
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
@stop