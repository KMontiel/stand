@extends('app')
@section('content')
<h1>
  Evento {{ $evento->s_descripcion}}
</h1>
 
<p>Id evento; {{ $evento->id_cliente}}</p>
<p>Descripcion: {{ $evento->s_descripcion}}</p>
<p>Fecha Inicio: {{ $evento->d_inicio }}</p>
<p>Fecha Fin: {{ $evento->d_fin}}</p>
<p>Reservado:{{ $evento->b_reserva_parcial}}</p>
<p>Habilitado{{ $evento->b_habilitado}}</p>
<p>Fecha creación: {{ $evento->created_at }}</p>
<hr>
 
<a href="{{ route('eventos.index') }}">Volver al índice</a>
<a href="{{ route('eventos.show', $evento->id_evento) }}">Recargar</a>
@stop