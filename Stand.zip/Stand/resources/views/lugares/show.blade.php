@extends('app')
@section('content')
<h1>
  Lugares {{ $lugar->s_descripcion}}
</h1>
 
<p>Id lugar; {{ $lugar->id_cliente}}</p>
<p>Descripcion: {{ $lugar->s_descripcion}}</p>
<p>Costo: {{ $lugar->n_costo }}</p>
<p>Habilitado{{ $lugar->b_habilitado}}</p>
<p>Fecha creación: {{ $lugar->created_at }}</p>
<hr>
 
<a href="{{ route('lugares.index') }}">Volver al índice</a>
<a href="{{ route('lugares.show', $lugar->id_lugar) }}">Recargar</a>
@stop