@extends('app')
@section('content')
<h1 class="text-primary">Lista de Lugares</h1>
 
<table class="table table-bordered" id="tableLugares">
  <thead>
    <tr>
        <th class="text-center">Id Lugar</th>
        <th class="text-center">Descripcion</th>
        <th class="text-center">Costo</th>
        <th class="text-center">Habilitado</th>
        <th class="text-center">Acciones</th>
    </tr>
  </thead>
  <tbody>
    @foreach($lugares as $lugar)
        <tr>
            <td class="text-center">{{ $lugar->id_lugar}}</td>
            <td class="text-center">{{ $lugar->s_descripcion}}</td>
            <td class="text-center">{{ $lugar->n_costo }}</td>
            <td class="text-center">{{ $lugar->b_habilitado}}</td>  
            <td>
                <a href="{{ route('lugares.show', $lugar->id_lugar) }}" class="btn btn-info">Ver</a>
            </td>
        </tr>
    @endforeach
  </tbody>
  <tfoot>
    <tr>     
    </tr>
  </tfoot>
</table>
@stop