<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::resource('clientes','ClientesController');
Route::get('api/v1/clientes','ClientesController@getClientes');

Route::resource('eventos','EventosController');
Route::get('api/v1/eventos','EventosController@getEventos');
Route::get('api/v1/evento/{id}','EventosController@getEvento');

Route::resource('lugares','LugaresController');
Route::get('api/v1/lugares','LugaresController@getLugares');

Route::resource('estados','EstadosController');
Route::get('api/v1/estados','EstadosController@getEstados');

Route::resource('ocupaciones','OcupacionController');
Route::get('api/v1/ocupaciones','OcupacionController@getOcupaciones');
Route::get('api/v1/estadoocupaciones/{id}','OcupacionController@getEstadoOcupaciones');
Route::get('api/v1/ocupacion/{id}','OcupacionController@getOcupacion');
Route::get('api/v1/ocupacioncliente/{id_e}/{id_l}','OcupacionController@getOcupacionDetalleCliente');
