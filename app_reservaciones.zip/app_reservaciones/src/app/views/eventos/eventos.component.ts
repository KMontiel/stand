import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { FormControl } from '@angular/forms';
import { NgxSmartModalComponent, NgxSmartModalService } from 'ngx-smart-modal';
import { Evento } from '../../models/evento';
import { EventoService } from '../../services/evento.service';
import { OcupacionService } from '../../services/ocupacion.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Ocupacion } from '../../models/ocupacion';


@Component({
  selector: 'eventos',
  templateUrl: './eventos.component.html',
  styleUrls: ['./eventos.component.scss']
})
export class EventosComponent implements OnInit {
  formEvento: FormGroup;
  rowsEventos = [];
  eventos = [];
  modeloEvento: Evento;
  ocupaciones:  Ocupacion[] = [];

  constructor(private servicioEvento: EventoService,
              private servicioOcupacion: OcupacionService,
              private formBuilder: FormBuilder,
              public ngxSmartModalService: NgxSmartModalService,
              ){
                this.modeloEvento = new Evento();
}

  ngOnInit() {    
    this.formEvento = this.formBuilder.group({
      id_evento: [0],
      s_descripcion: ['', Validators.compose([Validators.required, Validators.maxLength(50)])],
      d_inicio: ['', Validators.compose([Validators.required])],
      d_fin: ['', Validators.compose([Validators.required])],
      b_reserva_parcial: [],
      b_habilitado: [],
      created_at: [''],
      updated_at: [''],
    });

    this.getEventos(); 
  }

  /* <summary>
     Obtiene el listado de los eventos activos, consumiento
     el servicio de eventos "servicioEvento".
     </summary>
     <returns>void</returns> */
     getEventos() {
      this.servicioEvento.getAll()
        .subscribe(
        Evento => {
          this.rowsEventos = Evento;
          for (var i = 0; i < this.rowsEventos.length; i++) {
            this.eventos.push({ value: this.rowsEventos[i].id_evento, viewValue: this.rowsEventos[i].s_descripcion});
          }
        },
        (err: HttpErrorResponse) => {
          console.log(err);
          if (err.error instanceof Error) {
            console.log("Client-side error occured.");
          } else {
            console.log("Server-side error occured.");
          }
        }
        );
    }

  /* <summary>
     Consume el servicio de evento y pobla el modelo de evento
     para asignar los valores al formulario que permite visualizar
     la disponibilidad.
     </summary>
     <param name="id">Evento.id</param>
     <returns>void</returns> */
     getInfoEvento(id) {      
      this.servicioEvento.getById(id)
        .subscribe(
        Evento => {          
          this.modeloEvento = Evento;
          this.formEvento.setValue(this.modeloEvento);
          this.formEvento.disable();
        },
        (err: HttpErrorResponse) => {
          console.log(err);
          if (err.error instanceof Error) {
            console.log("Client-side error occured.");
          } else {
            console.log("Server-side error occured.");
          }
        }
        );
    }

      /* <summary>
     Obtiene la disponibilidad de lugares según un evento.
     </summary>
     <param name="id">Evento.id</param>
     <returns>void</returns> */
     getOcupacion(id) {      
      this.servicioOcupacion.getByEvento(id)
        .subscribe(
        Ocupacion => {
          this.ocupaciones= Ocupacion; 
        },
        (err: HttpErrorResponse) => {
          console.log(err);
          if (err.error instanceof Error) {
            console.log("Client-side error occured.");
          } else {
            console.log("Server-side error occured.");
          }
        }
      );
    }

     /* <summary>
     Muestra los datos de la ocupación del lugar según
     el evento
     </summary>
     <param name="id">Ocupaciob.id</param>
     <returns>void</returns> */
    muestraDetalle(id)
    {
      this.ngxSmartModalService.getModal('infoOcupacionModal').open();
    }
}
