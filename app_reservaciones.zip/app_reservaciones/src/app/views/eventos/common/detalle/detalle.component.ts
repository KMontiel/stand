import { Component,Input, OnInit } from '@angular/core';
import { OcupacionService } from '../../../../services/ocupacion.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Ocupacion } from '../../../../models/ocupacion';

@Component({
  selector: 'detalle',
  templateUrl: './detalle.component.html',
  styleUrls: ['./detalle.component.scss']
})
export class DetalleComponent implements OnInit{
  modeloOcupacion: Ocupacion;
  logo: string;
  @Input() ocupacion: Ocupacion; 

  constructor( private servicioOcupacion: OcupacionService,
              ){
                this.modeloOcupacion = new Ocupacion();
              }

  ngOnInit(){   
        this.getInfoOcupacion(this.ocupacion.id_ocupacion); 
  }

  /* <summary>
     Consume el servicio de ocupación para obtener
     el detalle.
     </summary>
     <param name="id">Ocupacion.id</param>
     <returns>void</returns> */
     getInfoOcupacion(id) {      
      this.servicioOcupacion.getById(id)
        .subscribe(
        Ocupacion => {          
          this.modeloOcupacion = Ocupacion;
          this.logo= "../../../../assets/img/clientes/"+this.modeloOcupacion.id_cliente+ ".png";
        },
        (err: HttpErrorResponse) => {
          console.log(err);
          if (err.error instanceof Error) {
            console.log("Client-side error occured.");
          } else {
            console.log("Server-side error occured.");
          }
        }
        );
    }
}