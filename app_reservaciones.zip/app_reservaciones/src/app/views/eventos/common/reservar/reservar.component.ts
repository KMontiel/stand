import { Component,Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Ocupacion } from '../../../../models/ocupacion';
import { OcupacionService } from '../../../../services/ocupacion.service';
import { Cliente } from '../../../../models/cliente';
import { ClienteService } from '../../../../services/cliente.service';
import { ModalDirective } from '../../../../../lib/angular-bootstrap-md/modals/modal.directive';

@Component({
  selector: 'reservar',
  templateUrl: './reservar.component.html',
  styleUrls: ['./reservar.component.scss']
})
export class ReservarComponent implements OnInit{
  modeloOcupacion: Ocupacion;
  modeloCliente: Cliente;
  rfcCliente:string;
  formRegistrar: FormGroup;
  formCliente: FormGroup;
  logo: string;
  is_edit: boolean = false;
  error: string;  
  b_error: boolean = true;

  @Input() ocupacion: Ocupacion; 
  @ViewChild('registrarModal') registrarModal: ModalDirective;
  @ViewChild('buscarrModal') BuscarModal: ModalDirective;

  constructor( private servicioOcupacion: OcupacionService,
               private servicioCliente: ClienteService,
               private fb: FormBuilder,
              ){
                this.modeloOcupacion = new Ocupacion();
                this.modeloCliente= new Cliente();
              }

  ngOnInit(){   
        this.getInfoOcupacion(this.ocupacion.id_ocupacion);    
        this.formCliente = this.fb.group({          
          id_cliente: [0],
          s_rfc: ['', Validators.compose([Validators.required])],         
          s_nombre: ['', Validators.compose([Validators.required])],
          s_descripcion:['', Validators.compose([Validators.required])],
          s_telefono:['', Validators.compose([Validators.required])],
          s_correo: ['', Validators.compose([Validators.required])],
        });

        this.formRegistrar = this.fb.group({    
          id_ocupacion:[0],
          d_inicio: ['', Validators.compose([Validators.required])],
          d_hora_inicio: [''],
          d_fin: ['', Validators.compose([Validators.required])],
          d_hora_fin: [''],
          d_registro: [''],
          d_hora_registro: [''],
          id_evento:[],
          id_lugar: [],
          lugar: [''],
          id_cliente: [],
          id_estado: [],
          estado: [],
          created_at: [''],
          updated_at: ['']
        });
  }

  /* <summary>
     Consume el servicio de ocupación para obtener
     el detalle.
     </summary>
     <param name="id">Ocupacion.id</param>
     <returns>void</returns> */
     getInfoOcupacion(id) {      
      this.servicioOcupacion.getById(id)
        .subscribe(
        Ocupacion => {          
          this.modeloOcupacion = Ocupacion;
          this.logo= "../../../../assets/img/clientes/"+this.modeloOcupacion.id_cliente+ ".png";
        },
        (err: HttpErrorResponse) => {
          console.log(err);
          if (err.error instanceof Error) {
            console.log("Client-side error occured.");
          } else {
            console.log("Server-side error occured.");
          }
        }
        );
    }

  /* <summary>
     Consume el servicio de clientes para buscar por
     rfc un id de cliente.
     </summary>
     <param name="id">Ocupacion.id</param>
     <returns>void</returns> */
     buscar(event: any) {   
      this.BuscarModal.hide(event);
      this.servicioCliente.getByRFC(this.rfcCliente)
        .subscribe(
        Cliente => {          
          this.modeloCliente = Cliente;      
          console.log(this.modeloCliente)  ;
          this.formCliente.setValue(this.modeloCliente);
          if( this.modeloCliente==null)
          {
            this.b_error=false;
            this.error="No se encontraron coincidencias. Favor de capturar información."
          }
          this.registrarModal.show();
        },
        (err: HttpErrorResponse) => {
          console.log(err);
          if (err.error instanceof Error) {
            console.log("Client-side error occured.");
          } else {
            console.log("Server-side error occured.");
          }
        }
        );
    }

    /* <summary>
     Consume el servicio de ocupacion para reserver un lugar
     </summary>
     <param name="id">Ocupacion.id</param>
     <returns>void</returns> */
     guardar() {      
      this.modeloCliente= this.formCliente.getRawValue();
      this.modeloOcupacion = this.formRegistrar.getRawValue();
        if (this.formCliente.valid && this.formRegistrar.valid) {
          if (this.is_edit) {
             this.servicioCliente.update(this.modeloCliente.id_cliente, this.modeloCliente)             
              .subscribe(
              data => {
                if (data == "success")
                {
                  this.reservar(this.modeloOcupacion);
                }
                else
                {
                  //mensaje false
                }
              },
              (err: HttpErrorResponse) => {
                console.log(err);
                if (err.error instanceof Error) {             
                  console.log("Client-side error occured.");
                } else {             
                  console.log("Server-side error occured.");
                }
              }
              );
      }
      else {
        this.servicioCliente.store(this.modeloCliente)
          .subscribe(
          data => {
            if (data == "success")
             {
              this.reservar(this.modeloOcupacion);
             }
            else
            {
              //mensaje false
            }
          },
          (err: HttpErrorResponse) => {
            console.log(err);
            if (err.error instanceof Error) {             
              console.log("Client-side error occured.");
            } else {             
              console.log("Server-side error occured.");
            }
          }
          );
      }
    }
    else { }
  }

  reservar(modeloOcupacion){
    this.servicioOcupacion.store(modeloOcupacion)             
      .subscribe(
      data => {
        if (data == "success")
        {
          //mensaje ok
        }
        else
        {
          //mensaje false
        }
      },
      (err: HttpErrorResponse) => {
        console.log(err);
        if (err.error instanceof Error) {             
          console.log("Client-side error occured.");
        } else {             
          console.log("Server-side error occured.");
        }
      }
    );
  }


  registro() {
    this.modeloCliente= new Cliente;
    this.registrarModal.hide();
    this.registrarModal.show();   
  }   
}