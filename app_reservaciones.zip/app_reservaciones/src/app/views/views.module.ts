import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatCheckboxModule, MatSelectModule, MatInputModule} from '@angular/material';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
import { AgmCoreModule } from '@agm/core';
import { CalendarModule } from 'angular-calendar';
import { SharedModule } from '../shared/shared.module';
import { FooterComponent } from '../main-layout/footer/footer.component';
import { EventosComponent } from './eventos/eventos.component';
import { TypographyComponent } from './css/typography/typography.component';
import { IconsComponent } from './css/icons/icons.component';
import { OcupacionCardComponent } from './eventos/common/ocupacion-card/ocupacion-card.component';
import { DetalleComponent } from './eventos/common/detalle/detalle.component';
import { ReservarComponent } from './eventos/common/reservar/reservar.component';
import { GridComponent } from './css/grid/grid.component';
import { MediaObjectComponent } from './css/media-object/media-object.component';
import { UtilitiesComponent } from './css/utilities/utilities.component';
import { ImagesComponent } from './css/images/images.component';
import { ColorsComponent } from './css/colors/colors.component';
import { ShadowComponent } from './css/shadow/shadow.component';
import { NgxSmartModalModule } from 'ngx-smart-modal';

import { HttpClientModule } from '@angular/common/http'; 
import { EventoService } from '../services/evento.service';
import { OcupacionService } from '../services/ocupacion.service';
import { ClienteService } from '../services/cliente.service';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    SharedModule,
    AgmCoreModule.forRoot({
      // https://developers.google.com/maps/documentation/javascript/get-api-key?hl=en#key
      apiKey: ''
    }),
    CalendarModule.forRoot(),
    MatButtonModule,
    MatCheckboxModule,
    MatSelectModule,
    HttpClientModule,
    MatInputModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    NgxSmartModalModule.forRoot()
  ],
  declarations: [
    FooterComponent,
    EventosComponent,
    TypographyComponent,
    IconsComponent,
    OcupacionCardComponent,
    DetalleComponent,
    ReservarComponent,
    GridComponent,
    MediaObjectComponent,
    UtilitiesComponent,
    ImagesComponent,
    ColorsComponent,
    ShadowComponent,
  ],
  exports: [
    FooterComponent,
    EventosComponent,
    TypographyComponent,
    IconsComponent,
    OcupacionCardComponent,
    GridComponent,
    MediaObjectComponent,
    UtilitiesComponent,
    ImagesComponent,
    ColorsComponent,
    ShadowComponent,

  ],
  providers: [EventoService, OcupacionService, ClienteService],
  schemas: [NO_ERRORS_SCHEMA]
})
export class ViewsModule { }
