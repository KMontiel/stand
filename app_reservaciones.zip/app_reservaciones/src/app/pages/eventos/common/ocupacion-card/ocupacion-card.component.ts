import { Component,Input, OnInit } from '@angular/core';
import { Ocupacion } from '../../../../models/ocupacion';

@Component({
  selector: 'ocupacion-card',
  templateUrl: './ocupacion-card.component.html',
  styleUrls: ['./ocupacion-card.component.scss']
})
export class OcupacionCardComponent implements OnInit{
  logo: string;
  @Input() ocupacion: Ocupacion; 

  ngOnInit(){
    if(this.ocupacion.id_cliente !=null)
     this.logo= "../../../../assets/img/clientes/"+this.ocupacion.id_cliente+ ".png";
    else
      this.logo="../../../../assets/img/clientes/disponible.jpg";
  }
}
