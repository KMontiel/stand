import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OcupacionCardComponent } from './ocupacion-card.component';

describe('OcupacionCardComponent', () => {
  let component: OcupacionCardComponent;
  let fixture: ComponentFixture<OcupacionCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OcupacionCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OcupacionCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
