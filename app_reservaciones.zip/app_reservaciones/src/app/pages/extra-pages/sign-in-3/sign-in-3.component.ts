import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'page-sign-in-3',
  templateUrl: './sign-in-3.component.html',
  styleUrls: ['./sign-in-3.component.scss']
})
export class PageSignIn3Component implements OnInit {
  constructor() { }

  ngOnInit() { }

  onSubmit() { }
}
