import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'page-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class PageForgotComponent implements OnInit {
  constructor() { }

  ngOnInit() { }

  onSubmit() { }
}
