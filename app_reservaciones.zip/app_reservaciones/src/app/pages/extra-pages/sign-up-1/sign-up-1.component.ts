import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'page-sign-up-1',
  templateUrl: './sign-up-1.component.html',
  styleUrls: ['./sign-up-1.component.scss']
})
export class PageSignUp1Component implements OnInit {
  constructor() { }

  ngOnInit() { }

  onSubmit() { }
}
