import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { map, catchError  } from 'rxjs/operators';
import { conex } from './conex';
import { Cliente } from '../models/cliente';

@Injectable()
export class ClienteService {
  s_ruta:string="clientes";
  constructor(private http:HttpClient) { }

  getById(id: number) :Observable<Cliente> {
    let url_aux=`/`+id;
    let url=conex.url+this.s_ruta+url_aux;
    return this.http.get<Cliente>(url).pipe(
      map( model =>{      
        console.log(model);
        return model;
    }))
  };
  
  getByRFC(rfc: string) :Observable<Cliente> {
    let url_aux=`/`+rfc;
    let url=conex.url+this.s_ruta+"/rfc"+url_aux;
    return this.http.get<Cliente>(url).pipe(
      map( model =>{      
        console.log(model);
        return model;
    }))
  };

  store(cliente: Cliente) {
    let url=conex.url+this.s_ruta;
    return this.http.post(url,cliente).pipe(
        map( model =>{      
            console.log(model);
            return model;
    }))
  }

  update(id: number, cliente: Cliente) {
    let url_aux=`/`+id;
    let url=conex.url+this.s_ruta+url_aux;
    return this.http.put(url,cliente).pipe(
      map( model =>{      
        console.log(model);
        return model;
    }))
  }

}
