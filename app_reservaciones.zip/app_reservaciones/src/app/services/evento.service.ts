import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { map, catchError  } from 'rxjs/operators';
import { conex } from './conex';
import { Evento } from '../models/evento';

@Injectable()
export class EventoService {
  constructor(private http:HttpClient) { }

  getAll():Observable<Evento[]>{    
    let url=conex.url+"eventos";   
    console.log('url', url);
    return this.http.get<Evento[]>(url).pipe(
      map( model =>{      
        //console.log(model);
        return model;
    }))
  };

  getById(id: number) :Observable<Evento> {
    let url_aux=`/`+id;
    let url=conex.url+"eventos"+url_aux;
    return this.http.get<Evento>(url).pipe(
      map( model =>{      
        //console.log(model);
        return model;
    }))
  };
}
