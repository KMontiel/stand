import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import { conex } from './conex';
import { Evento } from '../models/evento';

@Injectable()
export class EventoService {
  constructor(private http:Http) { }
  s_ruta:string="eventos";

  getAll():Observable<Evento[]>{    
    let url=conex.url+this.s_ruta; 
    return this.http.get(url)
    .map( respuesta =>{
          //console.log(respuesta);
          return respuesta.json().evento;
    })
  };

  getById(id: number) :Observable<Evento> {
    let url_aux=`/`+id;
    let url=conex.url+"eventos"+url_aux;
    return this.http.get(url)
    .map( respuesta =>{
      //console.log(respuesta);
      return respuesta.json().evento;
     })
  };
}
