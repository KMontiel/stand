export const conex = {
    url: 'http://192.168.1.74/Stand/public/api/'
  }
  