import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { conex } from './conex';
import { Ocupacion } from '../models/ocupacion';

@Injectable()
export class OcupacionService {
  constructor(private http:Http) { }
  
  getByEvento(id: number):Observable<Ocupacion[]> {
    let url_aux=`/`+id;
    let url=conex.url+"ocupacion/evento"+url_aux;
    return this.http.get(url)
    .map( respuesta =>{
      //console.log(respuesta);
      return respuesta.json().evento;
     })
  };
}
