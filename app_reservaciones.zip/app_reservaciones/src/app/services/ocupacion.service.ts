import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { map, catchError  } from 'rxjs/operators';
import { conex } from './conex';
import { Ocupacion } from '../models/ocupacion';

@Injectable()
export class OcupacionService {
  s_ruta:string="ocupacion";
  constructor(private http:HttpClient) { }

  getById(id: number) :Observable<Ocupacion> {
    let url_aux=`/`+id;
    let url=conex.url+this.s_ruta+url_aux;
    return this.http.get<Ocupacion>(url).pipe(
      map( model =>{      
        console.log(model);
        return model;
    }))
  };

  store(ocupacion: Ocupacion) {
    let url=conex.url+this.s_ruta;
    return this.http.post(url,ocupacion).pipe(
        map( model =>{      
            console.log(model);
            return model;
    }))
  }
  
  getByEvento(id: number) :Observable<Ocupacion[]> {
    let url_aux=`/`+id;
    let url=conex.url+"ocupacion/evento"+url_aux;
    return this.http.get<Ocupacion[]>(url).pipe(
      map( model =>{      
        console.log(model);
        return model;
    }))
  };
}
