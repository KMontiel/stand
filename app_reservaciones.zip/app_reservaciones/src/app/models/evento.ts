export class Evento {
    public id_evento: number;
    public s_descripcion: string;
    public d_inicio: string;
    public d_fin: string;
    public b_reserva_parcial: number;
    public b_habilitado: number;
    public created_at: string;
    public updated_at: string;
}