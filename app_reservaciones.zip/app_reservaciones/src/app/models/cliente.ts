export class Cliente {
    public id_cliente: number;
    public s_rfc: string;
    public s_nombre: string;
    public s_descripcion: string;
    public s_telefono: string;
    public s_correo: string;
}