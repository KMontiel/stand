export class Ocupacion {
    public id_ocupacion: number;
    public d_inicio: string;
    public d_hora_inicio: string;
    public d_fin: string;
    public d_hora_fin: string;
    public d_registro: string;
    public d_hora_registro: string;
    public id_evento: number;
    public id_lugar: number;
    public lugar: string;
    public id_cliente: number;
    public id_estado: number;
    public estado: string;
    public created_at: string;
    public updated_at: string;
}