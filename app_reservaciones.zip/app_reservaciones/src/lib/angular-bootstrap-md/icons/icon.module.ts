import { MdbIconComponent } from './icon.component';
import { NgModule } from '@angular/core';


@NgModule({
  declarations: [MdbIconComponent],
  exports: [MdbIconComponent]
})

export class IconsModule {

}
