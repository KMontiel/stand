export { CarouselComponent } from './carousel.component';
export { CarouselModule } from './carousel.module';
export { SlideComponent } from './slide.component';
export { CarouselConfig } from './carousel.config';
