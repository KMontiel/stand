export * from './chart.directive';
export { Color } from './color.service';
export { Colors } from './colors.service';
export { ChartsModule } from './chart.module';
