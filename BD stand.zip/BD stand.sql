-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.1.35-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win32
-- HeidiSQL Versión:             9.5.0.5293
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para stand
DROP DATABASE IF EXISTS `stand`;
CREATE DATABASE IF NOT EXISTS `stand` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `stand`;

-- Volcando estructura para tabla stand.c_clientes
DROP TABLE IF EXISTS `c_clientes`;
CREATE TABLE IF NOT EXISTS `c_clientes` (
  `id_cliente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `s_rfc` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `s_nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `s_descripcion` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `s_telefono` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `s_correo` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla stand.c_clientes: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `c_clientes` DISABLE KEYS */;
REPLACE INTO `c_clientes` (`id_cliente`, `s_rfc`, `s_nombre`, `s_descripcion`, `s_telefono`, `s_correo`, `created_at`, `updated_at`) VALUES
	(1, 'BEOV711207B26', 'victor manuel beristain ocaña', 'sistemas y soluciones SAPI', '2222388910', 'vberiso@gmail.com', '2018-09-28 12:57:55', '2018-09-29 03:44:57'),
	(2, 'HEFV881228DK5', 'Materiales Hernandez', 'Serviciso de Comercializacion de Materiales de construccion', '1234566790', 'materiales.hernandez.admon@gmail.com', '2018-09-28 22:29:15', '2018-09-28 22:29:15'),
	(3, 'MOMK821104FF2', 'Karla Montiel Morales', 'Consultoria en Servicios de Informatica', '1234567890', 'talis2m@gmail.com', '2018-09-28 22:30:10', '2018-09-28 22:30:10');
/*!40000 ALTER TABLE `c_clientes` ENABLE KEYS */;

-- Volcando estructura para tabla stand.c_estados
DROP TABLE IF EXISTS `c_estados`;
CREATE TABLE IF NOT EXISTS `c_estados` (
  `id_estado` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `s_descripcion` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla stand.c_estados: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `c_estados` DISABLE KEYS */;
REPLACE INTO `c_estados` (`id_estado`, `s_descripcion`, `created_at`, `updated_at`) VALUES
	(1, 'Disponible', '2018-09-28 14:52:49', '2018-09-28 14:52:50'),
	(2, 'Reservado', '2018-09-28 14:52:59', '2018-09-28 14:53:01'),
	(3, 'Ocupado', '2018-09-28 14:53:11', '2018-09-28 14:53:12');
/*!40000 ALTER TABLE `c_estados` ENABLE KEYS */;

-- Volcando estructura para tabla stand.c_eventos
DROP TABLE IF EXISTS `c_eventos`;
CREATE TABLE IF NOT EXISTS `c_eventos` (
  `id_evento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `s_descripcion` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `d_inicio` date NOT NULL,
  `d_fin` date NOT NULL,
  `b_reserva_parcial` tinyint(1) NOT NULL DEFAULT '0',
  `b_habilitado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_evento`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla stand.c_eventos: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `c_eventos` DISABLE KEYS */;
REPLACE INTO `c_eventos` (`id_evento`, `s_descripcion`, `d_inicio`, `d_fin`, `b_reserva_parcial`, `b_habilitado`, `created_at`, `updated_at`) VALUES
	(1, 'Expo Computacion', '2018-09-28', '2018-10-06', 0, 1, '2018-09-28 13:02:05', '2018-09-28 13:02:07'),
	(2, 'Boda y Quince Años', '2018-10-07', '2018-10-09', 0, 1, '2018-09-28 13:02:10', '2018-09-28 13:02:11'),
	(3, 'Auto show', '2018-09-25', '2018-09-27', 0, 1, '2018-09-28 13:35:49', '2018-09-28 13:35:50'),
	(4, 'Expo Construccion', '2018-09-29', '2018-10-03', 0, 1, '2018-09-28 13:36:29', '2018-09-28 13:36:30'),
	(5, 'Manualidades y Mas', '2018-09-26', '2018-10-02', 0, 1, '2018-09-28 13:53:09', '2018-09-28 13:53:10');
/*!40000 ALTER TABLE `c_eventos` ENABLE KEYS */;

-- Volcando estructura para tabla stand.c_lugares
DROP TABLE IF EXISTS `c_lugares`;
CREATE TABLE IF NOT EXISTS `c_lugares` (
  `id_lugar` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `s_descripcion` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `n_costo` decimal(10,2) NOT NULL,
  `b_habilitado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_lugar`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla stand.c_lugares: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `c_lugares` DISABLE KEYS */;
REPLACE INTO `c_lugares` (`id_lugar`, `s_descripcion`, `n_costo`, `b_habilitado`, `created_at`, `updated_at`) VALUES
	(1, 'Stand 1', 1200.00, 1, '2018-09-28 14:43:52', '2018-09-28 14:43:53'),
	(2, 'Stand 2', 2000.00, 1, '2018-09-28 14:44:07', '2018-09-28 14:44:09'),
	(3, 'Stand 3', 2000.00, 1, '2018-09-28 14:44:07', '2018-09-28 14:44:09'),
	(4, 'Stand 4', 2000.00, 1, '2018-09-28 14:44:07', '2018-09-28 14:44:09'),
	(5, 'Stand 5', 2000.00, 1, '2018-09-28 14:44:07', '2018-09-28 14:44:09'),
	(6, 'Stand 6', 2000.00, 1, '2018-09-28 14:44:07', '2018-09-28 14:44:09');
/*!40000 ALTER TABLE `c_lugares` ENABLE KEYS */;

-- Volcando estructura para tabla stand.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla stand.migrations: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
REPLACE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2018_09_28_021843_create_table_c_clientes_migration', 1),
	(2, '2018_09_28_172908_create_eventos_table', 1),
	(3, '2018_09_28_193137_create_lugares_table', 2),
	(4, '2018_09_28_194527_create_estados_table', 3),
	(5, '2018_09_28_200206_create_ocupacions_table', 4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Volcando estructura para tabla stand.t_ocupaciones
DROP TABLE IF EXISTS `t_ocupaciones`;
CREATE TABLE IF NOT EXISTS `t_ocupaciones` (
  `id_ocupacion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `d_inicio` date DEFAULT NULL,
  `d_hora_inicio` time DEFAULT NULL,
  `d_fin` date DEFAULT NULL,
  `d_hora_fin` time DEFAULT NULL,
  `d_registro` date DEFAULT NULL,
  `d_hora_registro` time DEFAULT NULL,
  `id_evento` int(11) DEFAULT NULL,
  `id_lugar` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `id_estado` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_ocupacion`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla stand.t_ocupaciones: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `t_ocupaciones` DISABLE KEYS */;
REPLACE INTO `t_ocupaciones` (`id_ocupacion`, `d_inicio`, `d_hora_inicio`, `d_fin`, `d_hora_fin`, `d_registro`, `d_hora_registro`, `id_evento`, `id_lugar`, `id_cliente`, `id_estado`, `created_at`, `updated_at`) VALUES
	(1, '2018-09-28', '15:33:36', '2018-09-29', '15:33:39', '2018-09-28', '15:33:43', 1, 1, 1, 1, '2018-09-28 15:33:52', '2018-09-28 15:33:54'),
	(2, '2018-09-28', '15:33:36', '2018-09-29', '15:33:39', '2018-09-28', '15:33:43', 2, 3, 2, 1, '2018-09-28 15:33:52', '2018-09-28 15:33:54'),
	(3, '2018-09-28', '15:33:36', '2018-09-29', '15:33:39', '2018-09-28', '15:33:43', 5, 6, 3, 1, '2018-09-28 15:33:52', '2018-09-28 15:33:54');
/*!40000 ALTER TABLE `t_ocupaciones` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
