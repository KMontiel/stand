export class Disponibilidad {
    public id_evento: number;
    public s_descripcion: string;
}