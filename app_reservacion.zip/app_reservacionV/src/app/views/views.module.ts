import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatCheckboxModule, MatSelectModule, MatInputModule} from '@angular/material';
import { AgmCoreModule } from '@agm/core';

import { CalendarModule } from 'angular-calendar';

import { SharedModule } from '../shared/shared.module';

import { FooterComponent } from '../main-layout/footer/footer.component';
import { EventosComponent } from './eventos/eventos.component';
import { TypographyComponent } from './css/typography/typography.component';
import { IconsComponent } from './css/icons/icons.component';
import { StatsCardComponent } from './eventos/common/stats-card/stats-card.component';
import { GridComponent } from './css/grid/grid.component';
import { MediaObjectComponent } from './css/media-object/media-object.component';
import { UtilitiesComponent } from './css/utilities/utilities.component';
import { ImagesComponent } from './css/images/images.component';
import { ColorsComponent } from './css/colors/colors.component';
import { ShadowComponent } from './css/shadow/shadow.component';

import { HttpClientModule } from '@angular/common/http'; 
import { EventoService } from '../services/evento.service';
import { DisponibilidadService } from '../services/disponibilidad.service';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    SharedModule,
    AgmCoreModule.forRoot({
      // https://developers.google.com/maps/documentation/javascript/get-api-key?hl=en#key
      apiKey: ''
    }),
    CalendarModule.forRoot(),
    MatButtonModule,
    MatCheckboxModule,
    MatSelectModule,
    HttpClientModule,
    MatInputModule
  ],
  declarations: [
    FooterComponent,
    EventosComponent,
    TypographyComponent,
    IconsComponent,
    StatsCardComponent,
    GridComponent,
    MediaObjectComponent,
    UtilitiesComponent,
    ImagesComponent,
    ColorsComponent,
    ShadowComponent,
  ],
  exports: [
    FooterComponent,
    EventosComponent,
    TypographyComponent,
    IconsComponent,
    StatsCardComponent,
    GridComponent,
    MediaObjectComponent,
    UtilitiesComponent,
    ImagesComponent,
    ColorsComponent,
    ShadowComponent,

  ],
  providers: [EventoService, DisponibilidadService],
  schemas: [NO_ERRORS_SCHEMA]
})
export class ViewsModule { }
