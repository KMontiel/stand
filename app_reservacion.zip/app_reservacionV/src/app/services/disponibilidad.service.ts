import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { map, catchError  } from 'rxjs/operators';
import { conex } from './conex';
import { Disponibilidad } from '../models/disponibilidad';

@Injectable()
export class DisponibilidadService {
  constructor(private http:HttpClient) { }
  
  getById(id: number) :Observable<Disponibilidad[]> {
    let url_aux=`/`+id;
    let url=conex.url+"estadoocupaciones"+url_aux;
    return this.http.get<Disponibilidad[]>(url).pipe(
      map( model =>{      
        console.log(model);
        return model;
    }))
  };
}
