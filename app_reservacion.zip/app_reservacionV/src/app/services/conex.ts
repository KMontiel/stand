export const conex = {
    url: 'http://192.168.1.66/Stand/public/api/v1/'
  }
  