
import { EventosComponent } from './views/eventos/eventos.component';
import { RouterModule, Route } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { NotFoundComponent } from './views/errors/not-found/not-found.component';

const routes: Route[] = [
  { path: '', pathMatch: 'full', redirectTo: 'eventos' },    
  { path: 'eventos', component: EventosComponent},
  { path: '**', component: NotFoundComponent },
];

export const AppRoutes: ModuleWithProviders = RouterModule.forRoot(routes);
